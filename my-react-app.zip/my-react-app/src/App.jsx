import { useState } from "react";

export default function FakeImageDetector() {
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleImageUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      setImage(file);
      setPreview(URL.createObjectURL(file));
      setError(null);
    }
  };

  const handleSubmit = async () => {
    if (!image) {
      setError("Please upload an image first.");
      return;
    }
    setLoading(true);
    setResult(null);
    setError(null);
    const formData = new FormData();
    formData.append("file", image);

    try {
      const response = await fetch("http://localhost:8000/predict", {
        method: "POST",
        body: formData,
      });
      if (!response.ok) {
        throw new Error("Failed to process image. Please try again.");
      }
      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error("Error detecting image:", error);
      setError(error.message || "An unexpected error occurred.");
    }
    setLoading(false);
  };

  return (
    <div className="flex flex-col items-center p-6 bg-gradient-to-br from-blue-100 to-white min-h-screen font-sans">
      <nav className="w-full bg-white shadow-md p-4 flex justify-center space-x-10 mb-10 rounded-lg">
        <a href="#" className="text-blue-600 font-semibold hover:underline">Home</a>
        <a href="#" className="text-blue-600 font-semibold hover:underline">FAQs</a>
        <a href="#" className="text-blue-600 font-semibold hover:underline">Blog</a>
        <a href="#" className="text-blue-600 font-semibold hover:underline">About Us</a>
        <a href="#" className="text-blue-600 font-semibold hover:underline">Contact Us</a>
      </nav>
      <div className="bg-white shadow-xl rounded-2xl p-8 w-full max-w-md text-center border border-blue-100">
        <h1 className="text-3xl font-extrabold mb-6 text-gray-800">🕵️‍♂️ Fake Image Detector</h1>
        <input 
          type="file" 
          accept="image/*" 
          onChange={handleImageUpload} 
          className="mb-4 block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-6 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer"
        />
        {preview && (
          <img 
            src={preview} 
            alt="Uploaded Preview" 
            className="w-full h-52 object-cover rounded-xl mb-4 border border-gray-300 shadow-sm"
          />
        )}
        <button 
          onClick={handleSubmit} 
          className={`w-full px-6 py-3 rounded-lg text-white font-semibold transition duration-200 ${loading ? 'bg-gray-400' : 'bg-blue-600 hover:bg-blue-700'}`} 
          disabled={loading}
        >
          {loading ? "Processing..." : "Upload & Detect"}
        </button>
        {loading && (
          <div className="mt-4 flex justify-center">
            <div className="w-6 h-6 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}
        {error && (
          <p className="mt-4 text-base font-medium text-red-600">⚠️ {error}</p>
        )}
        {result && (
          <div className="mt-6 text-left bg-blue-50 p-4 rounded-lg border border-blue-200 shadow-sm">
            <p className="text-sm text-gray-800 mb-1"><strong>📁 Filename:</strong> {result.filename}</p>
            <p className="text-sm text-gray-800 mb-1"><strong>✅ Real Probability:</strong> {(result.real_prob * 100).toFixed(2)}%</p>
            <p className="text-sm text-gray-800 mb-1"><strong>❌ Fake Probability:</strong> {(result.fake_prob * 100).toFixed(2)}%</p>
            <p className="text-lg font-bold mt-2">
              Verdict: <span className={result.verdict === 'FAKE' ? 'text-red-600' : 'text-green-600'}>{result.verdict}</span>
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
