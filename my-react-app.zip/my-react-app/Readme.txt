This is frontend.

1. First install Node.js
https://nodejs.org/en/blog/release/v22.14.0

2. Create the React project
https://learn.microsoft.com/en-us/windows/dev-environment/javascript/react-on-windows

3. npm install -D tailwindcss@3 postcss autoprefixer
   npx tailwindcss init -p
   
4. Edit tailwind.config.js:

/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
}

5. Edit src/index.css:
@tailwind base;
@tailwind components;
@tailwind utilities;

6. Run the frontend
   $cd my-react-app
   $npm run dev